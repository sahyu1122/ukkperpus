<?php
session_start();
include('koneksi.php');

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = 'user'; 

    
    $check = mysqli_query($koneksi, "SELECT * FROM user WHERE username='$username'");
    if ($check->num_rows > 0) {
        echo "Username sudah digunakan.";
    } else {

        $sql = "INSERT INTO user (username, password, role) VALUES ('$username', '$password', '$role')";
        $result = mysqli_query($koneksi, $sql);

        if ($result) {
            echo "Registrasi berhasil. Silakan <a href='login.php'>login</a>.";
        } else {
            echo "Registrasi gagal.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTER</title>
</head>
<body>
    <div>
        <h2>Form Registrasi</h2>
        <form action="register.php" method="post">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="submit" name="register" value="Register">
        </form>
        <p>Sudah punya akun? <a href="login.php">Login di sini</a>.</p>
    </div>
</body>
</html>
