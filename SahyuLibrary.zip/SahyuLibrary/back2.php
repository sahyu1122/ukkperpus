<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pengembalian Berhasil</title>
    <style>
       
    </style>
</head>
<body>
    <div class="box">
        <h1>✅ Buku Berhasil Dikembalikan</h1>
        <p>Terima kasih telah mengembalikan buku tepat waktu.</p>
        <a href="index.php">Kembali ke Menu Awal</a>
    </div>
</body>
</html>
